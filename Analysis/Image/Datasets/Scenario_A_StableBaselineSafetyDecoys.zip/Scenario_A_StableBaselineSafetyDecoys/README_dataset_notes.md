# A_STABLE_BASELINE_WITH_BENIGN_SAFETY_DECOYS

REAL-ONLY dataset. No synthetic images were generated.

Expected active focus: ['GENERAL_CHECK_IN']
Expected supporting focus: []

Run:
```powershell
.\push_to_phone_preserve_dates.bat
```

Only image folders are pushed to the phone. `expected_scenario.json` and
`gold_event_manifest.csv` stay on PC for developer-side comparison.
