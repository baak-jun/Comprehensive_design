# E_SAFETY_VISUAL_CUE_CHECK

REAL-ONLY dataset. No synthetic images were generated.

Expected active focus: ['SAFETY_AND_VIOLENCE']
Expected supporting focus: []

Run:
```powershell
.\push_to_phone_preserve_dates.bat
```

Only image folders are pushed to the phone. `expected_scenario.json` and
`gold_event_manifest.csv` stay on PC for developer-side comparison.
