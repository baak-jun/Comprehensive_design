@echo off
setlocal
set ADB=adb
where adb >nul 2>nul
if %ERRORLEVEL% neq 0 (
    if exist "B:\Android_Studio\SDK\platform-tools\adb.exe" set ADB=B:\Android_Studio\SDK\platform-tools\adb.exe
)
if "%ADB%"=="adb" (
    echo [ERROR] adb not found. Add Android SDK platform-tools to PATH or edit this BAT file.
    pause
    exit /b 1
)

echo Using ADB: %ADB%
%ADB% devices

echo Cleaning old gallery test folders...
%ADB% shell rm -rf /sdcard/DCIM/GalleryAnalysisTest
%ADB% shell rm -rf /sdcard/Pictures/GalleryAnalysisTest
%ADB% shell rm -rf /sdcard/Pictures/Screenshots/GalleryAnalysisTest
%ADB% shell rm -rf /sdcard/Pictures/KakaoTalk/GalleryAnalysisTest
%ADB% shell rm -rf /sdcard/Download/GalleryAnalysisTest

echo Creating folders...
%ADB% shell mkdir -p /sdcard/DCIM/GalleryAnalysisTest
%ADB% shell mkdir -p /sdcard/Pictures/GalleryAnalysisTest
%ADB% shell mkdir -p /sdcard/Pictures/Screenshots/GalleryAnalysisTest
%ADB% shell mkdir -p /sdcard/Pictures/KakaoTalk/GalleryAnalysisTest
%ADB% shell mkdir -p /sdcard/Download/GalleryAnalysisTest

echo Pushing image files only. Expectation JSON/CSV stay on PC.
if exist "DCIM\Camera" %ADB% push -a "DCIM\Camera" /sdcard/DCIM/GalleryAnalysisTest/
if exist "DCIM\PetCam" %ADB% push -a "DCIM\PetCam" /sdcard/DCIM/GalleryAnalysisTest/
if exist "DCIM\SportsCam" %ADB% push -a "DCIM\SportsCam" /sdcard/DCIM/GalleryAnalysisTest/
if exist "DCIM\TripsFamily" %ADB% push -a "DCIM\TripsFamily" /sdcard/DCIM/GalleryAnalysisTest/
if exist "DCIM\SchoolNotes" %ADB% push -a "DCIM\SchoolNotes" /sdcard/DCIM/GalleryAnalysisTest/
if exist "Pictures\Edited" %ADB% push -a "Pictures\Edited" /sdcard/Pictures/GalleryAnalysisTest/
if exist "Pictures\Screenshots" %ADB% push -a "Pictures\Screenshots" /sdcard/Pictures/Screenshots/GalleryAnalysisTest/
if exist "Download" %ADB% push -a "Download" /sdcard/Download/GalleryAnalysisTest/
if exist "KakaoTalk\Images" %ADB% push -a "KakaoTalk\Images" /sdcard/Pictures/KakaoTalk/GalleryAnalysisTest/

echo Triggering media scanner...
%ADB% shell am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d file:///sdcard/DCIM/GalleryAnalysisTest
%ADB% shell am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d file:///sdcard/Pictures/GalleryAnalysisTest
%ADB% shell am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d file:///sdcard/Pictures/Screenshots/GalleryAnalysisTest
%ADB% shell am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d file:///sdcard/Pictures/KakaoTalk/GalleryAnalysisTest
%ADB% shell am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d file:///sdcard/Download/GalleryAnalysisTest

echo Done. Open the phone Gallery app once, then run GalleryAnalysisModule v3.4.3.
pause
